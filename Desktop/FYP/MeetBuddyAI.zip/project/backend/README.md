# Flask Speaker Identification Backend

This Flask backend provides real speaker identification capabilities using SpeechBrain and SQLite database.

## Features

- **Real Speaker Identification**: Uses SpeechBrain ECAPA-TDNN model for speaker embeddings
- **Audio Processing**: Supports WAV, MP3, and M4A audio formats
- **SQLite Database**: Stores enrolled speaker profiles with embeddings
- **Admin Panel APIs**: Enroll, list, and delete speakers
- **Google Meet Integration**: Generate meeting links
- **CORS Enabled**: Ready for frontend integration

## API Endpoints

### Speaker Identification
- `POST /api/identify_speaker` - Identify speaker from audio file
- `POST /api/enroll_speaker` - Enroll new speaker with audio sample
- `GET /api/speakers` - List all enrolled speakers
- `DELETE /api/speakers/<speaker_id>` - Delete speaker

### Google Meet Integration
- `GET /api/get_meet_link` - Generate Google Meet link

### System
- `GET /api/health` - Health check endpoint

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the Flask server:
```bash
python app.py
```

The server will start on `http://localhost:5000`

## Usage

### Enroll Speaker
```bash
curl -X POST -F "audio=@speaker_sample.wav" -F "name=John Doe" http://localhost:5000/api/enroll_speaker
```

### Identify Speaker
```bash
curl -X POST -F "audio=@unknown_speaker.wav" http://localhost:5000/api/identify_speaker
```

### Get Meeting Link
```bash
curl http://localhost:5000/api/get_meet_link
```

## Database Schema

```sql
CREATE TABLE speakers (
    speaker_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    embedding BLOB NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Response Format

All endpoints return structured JSON responses:

```json
{
  "status": "success",
  "action": "speaker_identification | meeting_link",
  "speaker": "Speaker Name or 'Unknown Speaker'",
  "confidence": 0.0-1.0,
  "meeting_url": "https://meet.google.com/xxx-yyyy-zzz",
  "timestamp": "YYYY-MM-DD HH:MM:SS"
}
```

## Notes

- SpeechBrain model is downloaded automatically on first run
- Audio files are processed temporarily and deleted after processing
- Confidence threshold for speaker identification is set to 0.7 (adjustable)
- Google Meet links are generated with unique IDs (not actual Google API integration)