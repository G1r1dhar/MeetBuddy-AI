from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import numpy as np
import librosa
import torch
from speechbrain.pretrained import SpeakerRecognition
import pickle
import os
from datetime import datetime
import uuid
import tempfile
from werkzeug.utils import secure_filename
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'wav', 'mp3', 'm4a'}
DATABASE_PATH = 'speakers.db'

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Initialize SpeechBrain model
try:
    speaker_model = SpeakerRecognition.from_hparams(
        source="speechbrain/spkrec-ecapa-voxceleb",
        savedir="pretrained_models/spkrec-ecapa-voxceleb"
    )
    logger.info("SpeechBrain model loaded successfully")
except Exception as e:
    logger.error(f"Failed to load SpeechBrain model: {e}")
    speaker_model = None

def init_database():
    """Initialize SQLite database with speakers table"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS speakers (
            speaker_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            embedding BLOB NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()
    logger.info("Database initialized")

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_embedding(audio_path):
    """Extract speaker embedding from audio file using SpeechBrain"""
    try:
        if speaker_model is None:
            raise Exception("SpeechBrain model not loaded")
        
        # Load and preprocess audio
        signal, sample_rate = librosa.load(audio_path, sr=16000)
        
        # Convert to tensor
        signal_tensor = torch.tensor(signal).unsqueeze(0)
        
        # Extract embedding
        embedding = speaker_model.encode_batch(signal_tensor)
        
        # Convert to numpy array for storage
        embedding_np = embedding.squeeze().cpu().numpy()
        
        return embedding_np
    
    except Exception as e:
        logger.error(f"Error extracting embedding: {e}")
        return None

def compare_embeddings(embedding1, embedding2, threshold=0.8):
    """Compare two embeddings and return similarity score"""
    try:
        # Calculate cosine similarity
        dot_product = np.dot(embedding1, embedding2)
        norm1 = np.linalg.norm(embedding1)
        norm2 = np.linalg.norm(embedding2)
        
        similarity = dot_product / (norm1 * norm2)
        
        # Convert to confidence score (0-1)
        confidence = (similarity + 1) / 2  # Normalize from [-1,1] to [0,1]
        
        return confidence, confidence >= threshold
    
    except Exception as e:
        logger.error(f"Error comparing embeddings: {e}")
        return 0.0, False

def get_enrolled_speakers():
    """Get all enrolled speakers from database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('SELECT speaker_id, name, embedding FROM speakers')
    speakers = cursor.fetchall()
    
    conn.close()
    
    # Deserialize embeddings
    speaker_data = []
    for speaker_id, name, embedding_blob in speakers:
        embedding = pickle.loads(embedding_blob)
        speaker_data.append((speaker_id, name, embedding))
    
    return speaker_data

def identify_speaker(audio_embedding):
    """Identify speaker by comparing against enrolled speakers"""
    try:
        enrolled_speakers = get_enrolled_speakers()
        
        if not enrolled_speakers:
            return "Unknown Speaker", 0.0
        
        best_match = None
        best_confidence = 0.0
        
        for speaker_id, name, enrolled_embedding in enrolled_speakers:
            confidence, is_match = compare_embeddings(audio_embedding, enrolled_embedding)
            
            if confidence > best_confidence:
                best_confidence = confidence
                best_match = name
        
        # Return best match if confidence is above threshold
        if best_confidence >= 0.7:  # Adjustable threshold
            return best_match, best_confidence
        else:
            return "Unknown Speaker", best_confidence
    
    except Exception as e:
        logger.error(f"Error identifying speaker: {e}")
        return "Unknown Speaker", 0.0

@app.route('/api/identify_speaker', methods=['POST'])
def identify_speaker_endpoint():
    """API endpoint for speaker identification"""
    try:
        if 'audio' not in request.files:
            return jsonify({
                'status': 'error',
                'message': 'No audio file provided',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 400
        
        file = request.files['audio']
        
        if file.filename == '':
            return jsonify({
                'status': 'error',
                'message': 'No file selected',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 400
        
        if not allowed_file(file.filename):
            return jsonify({
                'status': 'error',
                'message': 'Unsupported file format. Use WAV, MP3, or M4A',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 400
        
        # Save uploaded file temporarily
        filename = secure_filename(file.filename)
        temp_path = os.path.join(UPLOAD_FOLDER, f"{uuid.uuid4()}_{filename}")
        file.save(temp_path)
        
        try:
            # Extract embedding from audio
            embedding = extract_embedding(temp_path)
            
            if embedding is None:
                return jsonify({
                    'status': 'error',
                    'message': 'Failed to process audio file',
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }), 500
            
            # Identify speaker
            speaker_name, confidence = identify_speaker(embedding)
            
            return jsonify({
                'status': 'success',
                'action': 'speaker_identification',
                'speaker': speaker_name,
                'confidence': float(confidence),
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
        
        finally:
            # Clean up temporary file
            if os.path.exists(temp_path):
                os.remove(temp_path)
    
    except Exception as e:
        logger.error(f"Error in speaker identification: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Internal server error',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }), 500

@app.route('/api/enroll_speaker', methods=['POST'])
def enroll_speaker():
    """API endpoint for enrolling a new speaker"""
    try:
        if 'audio' not in request.files or 'name' not in request.form:
            return jsonify({
                'status': 'error',
                'message': 'Audio file and speaker name required',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 400
        
        file = request.files['audio']
        speaker_name = request.form['name'].strip()
        
        if not speaker_name:
            return jsonify({
                'status': 'error',
                'message': 'Speaker name cannot be empty',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 400
        
        if not allowed_file(file.filename):
            return jsonify({
                'status': 'error',
                'message': 'Unsupported file format. Use WAV, MP3, or M4A',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 400
        
        # Save uploaded file temporarily
        filename = secure_filename(file.filename)
        temp_path = os.path.join(UPLOAD_FOLDER, f"{uuid.uuid4()}_{filename}")
        file.save(temp_path)
        
        try:
            # Extract embedding from audio
            embedding = extract_embedding(temp_path)
            
            if embedding is None:
                return jsonify({
                    'status': 'error',
                    'message': 'Failed to process audio file',
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }), 500
            
            # Store speaker in database
            speaker_id = str(uuid.uuid4())
            embedding_blob = pickle.dumps(embedding)
            
            conn = sqlite3.connect(DATABASE_PATH)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO speakers (speaker_id, name, embedding, created_at)
                VALUES (?, ?, ?, ?)
            ''', (speaker_id, speaker_name, embedding_blob, datetime.now()))
            
            conn.commit()
            conn.close()
            
            return jsonify({
                'status': 'success',
                'message': f'Speaker {speaker_name} enrolled successfully',
                'speaker_id': speaker_id,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
        
        finally:
            # Clean up temporary file
            if os.path.exists(temp_path):
                os.remove(temp_path)
    
    except Exception as e:
        logger.error(f"Error enrolling speaker: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Internal server error',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }), 500

@app.route('/api/speakers', methods=['GET'])
def list_speakers():
    """API endpoint to list all enrolled speakers"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('SELECT speaker_id, name, created_at FROM speakers ORDER BY created_at DESC')
        speakers = cursor.fetchall()
        
        conn.close()
        
        speaker_list = []
        for speaker_id, name, created_at in speakers:
            speaker_list.append({
                'speaker_id': speaker_id,
                'name': name,
                'created_at': created_at
            })
        
        return jsonify({
            'status': 'success',
            'speakers': speaker_list,
            'count': len(speaker_list),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    
    except Exception as e:
        logger.error(f"Error listing speakers: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Internal server error',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }), 500

@app.route('/api/speakers/<speaker_id>', methods=['DELETE'])
def delete_speaker(speaker_id):
    """API endpoint to delete a speaker"""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM speakers WHERE speaker_id = ?', (speaker_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({
                'status': 'error',
                'message': 'Speaker not found',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }), 404
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'status': 'success',
            'message': 'Speaker deleted successfully',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    
    except Exception as e:
        logger.error(f"Error deleting speaker: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Internal server error',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }), 500

@app.route('/api/get_meet_link', methods=['GET'])
def get_meet_link():
    """API endpoint to generate Google Meet link"""
    try:
        # Generate a unique meeting ID
        meeting_id = f"{uuid.uuid4().hex[:3]}-{uuid.uuid4().hex[:4]}-{uuid.uuid4().hex[:3]}"
        meeting_url = f"https://meet.google.com/{meeting_id}"
        
        return jsonify({
            'status': 'success',
            'action': 'meeting_link',
            'meeting_url': meeting_url,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    
    except Exception as e:
        logger.error(f"Error generating meet link: {e}")
        return jsonify({
            'status': 'error',
            'message': 'Failed to generate meeting link',
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'success',
        'message': 'Flask backend is running',
        'speechbrain_loaded': speaker_model is not None,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

if __name__ == '__main__':
    # Initialize database on startup
    init_database()
    
    # Run Flask app
    app.run(debug=True, host='0.0.0.0', port=5000)