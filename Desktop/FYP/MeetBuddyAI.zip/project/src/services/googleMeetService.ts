interface TranscriptSegment {
  text: string;
  timestamp: string;
  speaker?: string;
  confidence: number;
}

class GoogleMeetService {
  private recognition: any = null;
  private retryCount = 0;
  private mediaRecorder: MediaRecorder | null = null;
  private audioStream: MediaStream | null = null;
  private isRecording = false;
  private transcriptCallback: ((segment: TranscriptSegment) => void) | null = null;
  private errorCallback: ((error: string) => void) | null = null;

  async startTranscription(
    callback: (segment: TranscriptSegment) => void,
    errorCallback?: (error: string) => void
  ): Promise<void> {
    this.transcriptCallback = callback;
    this.errorCallback = errorCallback || null;

    try {
      // Request microphone access
      this.audioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 16000,
        },
      });

      // Create MediaRecorder for audio capture
      this.mediaRecorder = new MediaRecorder(this.audioStream, {
        mimeType: 'audio/webm;codecs=opus',
      });

      const audioChunks: Blob[] = [];

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.push(event.data);
        }
      };

      this.mediaRecorder.start(1000); // Capture audio in 1-second chunks
      this.isRecording = true;

      this.retryCount = 0;
      // Use Web Speech API for transcription
      this.startWebSpeechAPI();

    } catch (error) {
      console.error('Error starting transcription:', error);
      throw new Error('Failed to start audio capture');
    }
  }

  private startWebSpeechAPI(): void {
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    
    if (!SpeechRecognition) {
      const errorMessage = 'Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.';
      console.warn(errorMessage);
      if (this.errorCallback) {
        this.errorCallback(errorMessage);
      }
      return;
    }

    this.recognition = new SpeechRecognition();
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';
    this.recognition.maxAlternatives = 1;

    this.recognition.onresult = (event: any) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          const segment: TranscriptSegment = {
            text: result[0].transcript,
            timestamp: new Date().toISOString(),
            confidence: result[0].confidence || 0.8,
          };
          this.transcriptCallback?.(segment);
        }
      }
    };

    this.recognition.onerror = (event: any) => {
      const errorMessage = this.getErrorMessage(event.error);
      
      // Handle network errors with retry logic
      if (event.error === 'network' && this.retryCount < 3) {
        this.retryCount++;
        console.warn(`Speech recognition network error - retrying (attempt ${this.retryCount}/3)...`);
        console.log(`Retrying speech recognition (attempt ${this.retryCount}/3)...`);
        
        // Wait 2 seconds before retrying
        setTimeout(() => {
          if (this.isRecording) {
            this.startWebSpeechAPI();
          }
        }, 2000);
      } else {
        // Max retries reached or different error
        console.error('Speech recognition error:', event.error);
        if (this.errorCallback) {
          this.errorCallback(errorMessage);
        }
      }
    };

    this.recognition.onend = () => {
      // Restart recognition if still recording and no error occurred
      if (this.isRecording && this.retryCount === 0) {
        setTimeout(() => {
          if (this.isRecording) {
            this.startWebSpeechAPI();
          }
        }, 100);
      }
    };

    try {
      this.recognition.start();
    } catch (error) {
      console.error('Failed to start speech recognition:', error);
      if (this.errorCallback) {
        this.errorCallback('Failed to start speech recognition. Please check your microphone permissions.');
      }
    }
  }

  private getErrorMessage(errorType: string): string {
    switch (errorType) {
      case 'network':
        return 'Network error occurred. Retrying connection... Please ensure you have a stable internet connection.';
      case 'not-allowed':
        return 'Microphone access denied. Please allow microphone permissions and try again.';
      case 'no-speech':
        return 'No speech detected. Please speak clearly into your microphone.';
      case 'audio-capture':
        return 'Audio capture failed. Please check your microphone settings.';
      case 'service-not-allowed':
        return 'Speech recognition service not allowed. Please check your browser settings.';
      default:
        return `Speech recognition error: ${errorType}. Please try again.`;
    }
  }

  stopTranscription(): void {
    this.isRecording = false;
    this.retryCount = 0;

    if (this.recognition) {
      this.recognition.stop();
      this.recognition = null;
    }

    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
    }

    if (this.audioStream) {
      this.audioStream.getTracks().forEach(track => track.stop());
      this.audioStream = null;
    }

    this.transcriptCallback = null;
  }

  isCurrentlyRecording(): boolean {
    return this.isRecording;
  }

  // Google Meet integration methods
  async joinMeetingFromLink(meetLink: string): Promise<void> {
    // Extract meeting ID from Google Meet link
    const meetingId = this.extractMeetingId(meetLink);
    
    if (!meetingId) {
      throw new Error('Invalid Google Meet link');
    }

    // In a real implementation, this would use Google Meet API
    console.log('Joining meeting:', meetingId);
    
    // Start transcription automatically when joining
    // This would be integrated with Google Meet's audio stream
  }

  private extractMeetingId(meetLink: string): string | null {
    const regex = /meet\.google\.com\/([a-z-]+)/;
    const match = meetLink.match(regex);
    return match ? match[1] : null;
  }

  async generateSummary(transcript: string): Promise<string> {
    // In production, integrate with OpenAI or other AI service
    const mockSummary = `
Meeting Summary:
- Key discussion points covered
- Action items identified
- Next steps outlined
- Participants: ${Math.floor(Math.random() * 5) + 2} people
- Duration: ${Math.floor(Math.random() * 60) + 15} minutes
    `.trim();

    return mockSummary;
  }
}

export const googleMeetService = new GoogleMeetService();
export type { TranscriptSegment };