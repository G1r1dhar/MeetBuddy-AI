import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle: string;
  icon: LucideIcon;
  gradient: string;
  iconColor?: string;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  gradient,
  iconColor = 'text-white'
}) => {
  return (
    <div className={`${gradient} rounded-xl p-6 shadow-xl transform hover:scale-105 transition-all duration-300 hover:shadow-2xl`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium opacity-90 mb-1">{title}</p>
          <p className="text-3xl font-bold mb-1">{value}</p>
          <p className="text-sm opacity-75">{subtitle}</p>
        </div>
        <div className={`p-3 rounded-lg bg-white bg-opacity-20 backdrop-blur-sm ${iconColor}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
};

export default StatCard;