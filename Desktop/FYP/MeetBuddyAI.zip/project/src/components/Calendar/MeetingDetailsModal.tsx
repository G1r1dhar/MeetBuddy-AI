import React from 'react';
import { X, Clock, Users, Video, Edit, Trash2, Bell, Repeat, FileText, CheckSquare } from 'lucide-react';
import Button from '../UI/Button';
import moment from 'moment';

interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  resource?: {
    type: 'meeting' | 'reminder';
    meetLink?: string;
    participants?: string[];
    description?: string;
    meetingType?: string;
    recurring?: boolean;
    reminderTime?: string;
    actionItems?: string[];
    summary?: string;
    notes?: string;
  };
}

interface MeetingDetailsModalProps {
  event: CalendarEvent;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (event: CalendarEvent) => void;
  onDelete: (eventId: string) => void;
  onJoinMeeting: (meetLink: string) => void;
}

const MeetingDetailsModal: React.FC<MeetingDetailsModalProps> = ({
  event,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onJoinMeeting
}) => {
  if (!isOpen) return null;

  const isPastMeeting = moment(event.end).isBefore(moment());
  const isUpcoming = moment(event.start).isAfter(moment());
  const isOngoing = moment().isBetween(moment(event.start), moment(event.end));

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-white">{event.title}</h3>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-800 transition-colors"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        <div className="space-y-4 mb-6">
          {/* Date and Time */}
          <div className="flex items-center space-x-2 text-gray-300">
            <Clock className="w-5 h-5" />
            <div>
              <span className="font-medium">
                {moment(event.start).format('MMMM DD, YYYY')}
              </span>
              <span className="mx-2">•</span>
              <span>
                {moment(event.start).format('HH:mm')} - {moment(event.end).format('HH:mm')}
              </span>
              <span className="mx-2">•</span>
              <span className="text-gray-400">
                {moment.duration(moment(event.end).diff(moment(event.start))).humanize()}
              </span>
            </div>
          </div>

          {/* Status */}
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${
              isOngoing ? 'bg-green-500 animate-pulse' :
              isUpcoming ? 'bg-blue-500' : 'bg-gray-500'
            }`}></div>
            <span className={`text-sm font-medium ${
              isOngoing ? 'text-green-400' :
              isUpcoming ? 'text-blue-400' : 'text-gray-400'
            }`}>
              {isOngoing ? 'Ongoing' : isUpcoming ? 'Upcoming' : 'Completed'}
            </span>
          </div>
          
          {/* Participants */}
          {event.resource?.participants && event.resource.participants.length > 0 && (
            <div className="flex items-start space-x-2 text-gray-300">
              <Users className="w-5 h-5 mt-0.5" />
              <div>
                <p className="font-medium mb-1">Participants ({event.resource.participants.length})</p>
                <div className="flex flex-wrap gap-2">
                  {event.resource.participants.map((participant, index) => (
                    <span key={index} className="bg-gray-800 px-2 py-1 rounded text-sm">
                      {participant}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Meeting Type */}
          {event.resource?.meetingType && (
            <div className="flex items-center space-x-2 text-gray-300">
              <Video className="w-5 h-5" />
              <span className="capitalize">{event.resource.meetingType.replace('-', ' ')}</span>
            </div>
          )}

          {/* Recurring */}
          {event.resource?.recurring && (
            <div className="flex items-center space-x-2 text-gray-300">
              <Repeat className="w-5 h-5" />
              <span>Recurring meeting</span>
            </div>
          )}

          {/* Reminder */}
          {event.resource?.reminderTime && (
            <div className="flex items-center space-x-2 text-gray-300">
              <Bell className="w-5 h-5" />
              <span>Reminder: {event.resource.reminderTime} minutes before</span>
            </div>
          )}
          
          {/* Description */}
          {event.resource?.description && (
            <div className="text-gray-300">
              <p className="font-medium mb-2">Description</p>
              <p className="text-gray-400 bg-gray-800 p-3 rounded-lg">
                {event.resource.description}
              </p>
            </div>
          )}

          {/* Action Items */}
          {event.resource?.actionItems && event.resource.actionItems.length > 0 && (
            <div className="text-gray-300">
              <div className="flex items-center space-x-2 mb-2">
                <CheckSquare className="w-5 h-5" />
                <p className="font-medium">Action Items</p>
              </div>
              <ul className="space-y-1 text-gray-400">
                {event.resource.actionItems.map((item, index) => (
                  <li key={index} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Meeting Summary */}
          {event.resource?.summary && isPastMeeting && (
            <div className="text-gray-300">
              <div className="flex items-center space-x-2 mb-2">
                <FileText className="w-5 h-5" />
                <p className="font-medium">Meeting Summary</p>
              </div>
              <p className="text-gray-400 bg-gray-800 p-3 rounded-lg">
                {event.resource.summary}
              </p>
            </div>
          )}

          {/* Meeting Notes */}
          {event.resource?.notes && isPastMeeting && (
            <div className="text-gray-300">
              <div className="flex items-center space-x-2 mb-2">
                <FileText className="w-5 h-5" />
                <p className="font-medium">Notes</p>
              </div>
              <p className="text-gray-400 bg-gray-800 p-3 rounded-lg">
                {event.resource.notes}
              </p>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-3">
          {event.resource?.meetLink && (isUpcoming || isOngoing) && (
            <Button 
              icon={Video} 
              onClick={() => onJoinMeeting(event.resource!.meetLink!)}
              className="shadow-lg shadow-yellow-400/50"
            >
              Join Meeting
            </Button>
          )}
          
          {isUpcoming && (
            <Button 
              icon={Edit} 
              onClick={() => onEdit(event)}
              variant="secondary"
            >
              Edit
            </Button>
          )}
          
          <Button 
            icon={Trash2} 
            onClick={() => onDelete(event.id)}
            variant="outline"
            className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
          >
            Delete
          </Button>
          
          <Button 
            variant="outline" 
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MeetingDetailsModal;