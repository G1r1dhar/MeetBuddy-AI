import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import AdminLayout from './components/Admin/AdminLayout';
import Dashboard from './pages/Dashboard';
import Meetings from './pages/Meetings';
import Calendar from './pages/Calendar';
import Settings from './pages/Settings';
import Login from './pages/Login';
import LiveTranscript from './pages/LiveTranscript';
import AdminDashboard from './pages/Admin/AdminDashboard';
import UserManagement from './pages/Admin/UserManagement';
import ContentManagement from './pages/Admin/ContentManagement';
import MeetingManagement from './pages/Admin/MeetingManagement';
import Reports from './pages/Admin/Reports';
import AdminSettings from './pages/Admin/AdminSettings';
import { NotificationProvider } from './contexts/NotificationContext';
import { AuthProvider } from './contexts/AuthContext';

function App() {
  return (
    <AuthProvider>
    <NotificationProvider>
      <Router>
        <AppRoutes />
      </Router>
    </NotificationProvider>
    </AuthProvider>
  );
}

function AppRoutes() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState<'admin' | 'user'>('user');

  useEffect(() => {
    const authToken = localStorage.getItem('authToken');
    const role = localStorage.getItem('userRole') as 'admin' | 'user' || 'user';
    setIsAuthenticated(!!authToken);
    setUserRole(role);
  }, []);

  if (!isAuthenticated) {
    return <Login onLogin={(role) => {
      setIsAuthenticated(true);
      setUserRole(role);
    }} />;
  }

  if (userRole === 'admin') {
    return (
      <AdminLayout>
        <Routes>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/users" element={<UserManagement />} />
          <Route path="/admin/content" element={<ContentManagement />} />
          <Route path="/admin/meetings" element={<MeetingManagement />} />
          <Route path="/admin/reports" element={<Reports />} />
          <Route path="/admin/settings" element={<AdminSettings />} />
          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Routes>
      </AdminLayout>
    );
  }
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/meetings" element={<Meetings />} />
        <Route path="/calendar" element={<Calendar />} />
        <Route path="/live-transcript" element={<LiveTranscript />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}

export default App;