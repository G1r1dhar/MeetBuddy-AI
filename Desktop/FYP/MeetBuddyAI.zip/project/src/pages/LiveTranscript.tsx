import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Play, Pause, Square, Download, Users, Link } from 'lucide-react';
import Button from '../components/UI/Button';
import { useNotifications } from '../contexts/NotificationContext';
import { googleMeetService, TranscriptSegment } from '../services/googleMeetService';

const LiveTranscript: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [transcriptSegments, setTranscriptSegments] = useState<TranscriptSegment[]>([]);
  const [meetLink, setMeetLink] = useState('');
  const [duration, setDuration] = useState(0);
  const [participants] = useState(['John Doe', 'Alice Smith', 'Bob Johnson']);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const { addNotification } = useNotifications();

  const handleTranscriptSegment = (segment: TranscriptSegment) => {
    setTranscriptSegments(prev => [...prev, segment]);
  };

  useEffect(() => {
    if (isRecording && !isPaused) {
      intervalRef.current = setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRecording, isPaused]);

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const startRecording = async () => {
    try {
      await googleMeetService.startTranscription(
        handleTranscriptSegment,
        (error: string) => {
          setIsRecording(false);
          setIsPaused(false);
          addNotification({
            title: 'Speech Recognition Error',
            message: error,
            type: 'error'
          });
        }
      );
      setIsRecording(true);
      setIsPaused(false);
      addNotification({
        title: 'Recording Started',
        message: 'Live transcript recording has begun. Speech will be converted to text in real-time.',
        type: 'success'
      });
    } catch (error) {
      addNotification({
        title: 'Recording Failed',
        message: 'Failed to start recording. Please check microphone permissions.',
        type: 'error'
      });
    }
  };

  const joinMeetAndRecord = async () => {
    if (!meetLink) {
      addNotification({
        title: 'Invalid Link',
        message: 'Please enter a valid Google Meet link.',
        type: 'error'
      });
      return;
    }

    try {
      await googleMeetService.joinMeetingFromLink(meetLink);
      await startRecording();
      addNotification({
        title: 'Joined Meeting',
        message: 'Successfully joined Google Meet and started recording.',
        type: 'success'
      });
    } catch (error) {
      addNotification({
        title: 'Failed to Join',
        message: 'Could not join the Google Meet session.',
        type: 'error'
      });
    }
  };

  const startManualRecording = () => {
    setIsRecording(true);
    setIsPaused(false);
    addNotification({
      title: 'Recording Started',
      message: 'Live transcript recording has begun. Speech will be converted to text in real-time.',
      type: 'success'
    });
  };

  const pauseRecording = () => {
    setIsPaused(true);
    addNotification({
      title: 'Recording Paused',
      message: 'Transcript recording has been paused.',
      type: 'info'
    });
  };

  const resumeRecording = () => {
    setIsPaused(false);
    addNotification({
      title: 'Recording Resumed',
      message: 'Transcript recording has been resumed.',
      type: 'success'
    });
  };

  const stopRecording = () => {
    setIsRecording(false);
    setIsPaused(false);
    googleMeetService.stopTranscription();
    addNotification({
      title: 'Recording Stopped',
      message: 'Transcript recording has stopped. AI summary generation will begin shortly.',
      type: 'info'
    });
  };

  const exportTranscript = () => {
    const transcript = transcriptSegments.map(s => `[${s.timestamp}] ${s.text}`).join('\n');
    const element = document.createElement('a');
    const file = new Blob([transcript], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `meeting-transcript-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    addNotification({
      title: 'Transcript Exported',
      message: 'Meeting transcript has been downloaded successfully.',
      type: 'success'
    });
  };

  const generateSummary = async () => {
    const transcript = transcriptSegments.map(s => s.text).join(' ');
    if (!transcript) {
      addNotification({
        title: 'No Transcript',
        message: 'No transcript available to summarize.',
        type: 'warning'
      });
      return;
    }

    try {
      const summary = await googleMeetService.generateSummary(transcript);
      addNotification({
        title: 'Summary Generated',
        message: 'AI summary has been generated successfully.',
        type: 'success'
      });
      // In a real app, you'd display this summary somewhere
      console.log('Generated summary:', summary);
    } catch (error) {
      addNotification({
        title: 'Summary Failed',
        message: 'Failed to generate AI summary.',
        type: 'error'
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Live Transcript</h1>
          <p className="text-gray-400">Real-time speech-to-text conversion for your meetings</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1 text-gray-400">
            <Users className="w-4 h-4" />
            <span className="text-sm">{participants.length} participants</span>
          </div>
        </div>
      </div>

      {/* Google Meet Integration */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Google Meet Integration</h3>
        <div className="flex flex-col lg:flex-row gap-4">
          <input
            type="url"
            value={meetLink}
            onChange={(e) => setMeetLink(e.target.value)}
            placeholder="Enter Google Meet link (e.g., https://meet.google.com/abc-defg-hij)"
            className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
          />
          <Button 
            icon={Link} 
            onClick={joinMeetAndRecord}
            disabled={isRecording || !meetLink}
          >
            Join & Record
          </Button>
        </div>
      </div>

      {/* Recording Controls */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
          <div className="flex items-center space-x-4">
            <div className={`w-4 h-4 rounded-full ${isRecording && !isPaused ? 'bg-red-500 animate-pulse' : 'bg-gray-500'}`}></div>
            <div>
              <p className="text-white font-semibold">
                {isRecording ? (isPaused ? 'Recording Paused' : 'Recording Active') : 'Ready to Record'}
              </p>
              <p className="text-gray-400 text-sm">Duration: {formatDuration(duration)}</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {!isRecording ? (
              <Button icon={Mic} onClick={startManualRecording}>
                Start Recording
              </Button>
            ) : (
              <>
                {isPaused ? (
                  <Button icon={Play} onClick={resumeRecording} variant="secondary">
                    Resume
                  </Button>
                ) : (
                  <Button icon={Pause} onClick={pauseRecording} variant="secondary">
                    Pause
                  </Button>
                )}
                <Button icon={Square} onClick={stopRecording} variant="outline">
                  Stop
                </Button>
              </>
            )}
            {transcriptSegments.length > 0 && (
              <Button icon={Sparkles} onClick={generateSummary} variant="outline" size="sm">
                Generate Summary
              </Button>
            )}
            {transcriptSegments.length > 0 && (
              <Button icon={Download} onClick={exportTranscript} variant="outline" size="sm">
                Export
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Participants */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Participants</h3>
        <div className="flex flex-wrap gap-3">
          {participants.map((participant, index) => (
            <div key={index} className="flex items-center space-x-2 bg-gray-800 rounded-lg px-3 py-2">
              <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-black text-sm font-bold">{participant.split(' ').map(n => n[0]).join('')}</span>
              </div>
              <span className="text-white text-sm">{participant}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Transcript */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="p-6 border-b border-gray-800">
          <h3 className="text-lg font-semibold text-white">Live Transcript</h3>
        </div>
        <div className="p-6">
          {transcriptSegments.length > 0 ? (
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {transcriptSegments.map((segment, index) => (
                <div key={index} className="text-gray-300 leading-relaxed">
                  <div className="flex items-start space-x-3">
                    <span className="text-xs text-gray-500 mt-1 min-w-0">
                      {new Date(segment.timestamp).toLocaleTimeString()}
                    </span>
                    <div className="flex-1">
                      <span className="text-white">{segment.text}</span>
                      <span className="text-xs text-gray-500 ml-2">
                        ({Math.round(segment.confidence * 100)}% confidence)
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <MicOff className="w-16 h-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No transcript available</p>
              <p className="text-sm text-gray-500 mt-2">Start recording to see live transcription</p>
            </div>
          )}
        </div>
      </div>

      {/* AI Insights (placeholder) */}
      {transcriptSegments.length > 0 && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">AI Insights</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-800 rounded-lg p-4">
              <h4 className="font-semibold text-yellow-400 mb-2">Key Topics</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Project updates</li>
                <li>• Team collaboration</li>
                <li>• Recent findings</li>
              </ul>
            </div>
            <div className="bg-gray-800 rounded-lg p-4">
              <h4 className="font-semibold text-yellow-400 mb-2">Action Items</h4>
              <ul className="text-sm text-gray-300 space-y-1">
                <li>• Follow up on findings</li>
                <li>• Schedule next meeting</li>
                <li>• Share presentation</li>
              </ul>
            </div>
            <div className="bg-gray-800 rounded-lg p-4">
              <h4 className="font-semibold text-yellow-400 mb-2">Sentiment</h4>
              <div className="text-sm text-gray-300">
                <div className="flex items-center space-x-2 mb-1">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span>Positive: 80%</span>
                </div>
                <div className="flex items-center space-x-2 mb-1">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span>Neutral: 15%</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span>Negative: 5%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LiveTranscript;