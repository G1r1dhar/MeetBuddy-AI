import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Calendar,
  CalendarDays, 
  Monitor, 
  Moon, 
  Sun,
  Trash2,
  Save,
  Download
} from 'lucide-react';
import Button from '../components/UI/Button';
import { useNotifications } from '../contexts/NotificationContext';

const Settings: React.FC = () => {
  const [settings, setSettings] = useState({
    notifications: {
      meetingReminders: true,
      aiSummaryReady: true,
      systemUpdates: false
    },
    googleMeet: {
      autoGenerateNotes: true,
      enableLiveTranscript: true,
      autoExportSummaries: false
    },
    calendar: {
      enableSync: true,
      reminderNotifications: true,
      defaultMeetingDuration: 30,
      autoJoinMeetings: false
    },
    account: {
      name: 'John Doe',
      email: 'john@meetbuddy.ai',
      plan: 'Free'
    }
  });

  const { addNotification } = useNotifications();

  const handleToggle = (section: string, key: string) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [key]: !prev[section as keyof typeof prev][key as keyof (typeof prev)[typeof section]]
      }
    }));
  };

  const saveSettings = () => {
    addNotification({
      title: 'Settings Saved',
      message: 'Your preferences have been updated successfully.',
      type: 'success'
    });
  };

  const exportData = () => {
    addNotification({
      title: 'Data Export Started',
      message: 'Your data export has begun. You will receive an email when ready.',
      type: 'info'
    });
  };

  const deleteAccount = () => {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      addNotification({
        title: 'Account Deletion Requested',
        message: 'Your account deletion request has been submitted. You will receive a confirmation email.',
        type: 'warning'
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Settings</h1>
        <p className="text-gray-400">Manage your account preferences and application settings</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Notification Settings */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <Bell className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">Notifications</h3>
          </div>
          
          <div className="space-y-4">
            {Object.entries(settings.notifications).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-white capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </span>
                <button
                  onClick={() => handleToggle('notifications', key)}
                  className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                    value ? 'bg-yellow-400' : 'bg-gray-700'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                    value ? 'right-0.5' : 'left-0.5'
                  }`}></div>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Google Meet Preferences */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <SettingsIcon className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">Google Meet Preferences</h3>
          </div>
          
          <div className="space-y-4">
            {Object.entries(settings.googleMeet).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-white capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </span>
                <button
                  onClick={() => handleToggle('googleMeet', key)}
                  className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                    value ? 'bg-yellow-400' : 'bg-gray-700'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                    value ? 'right-0.5' : 'left-0.5'
                  }`}></div>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Calendar Settings */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <CalendarDays className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">Calendar Settings</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Default Meeting Duration (minutes)</label>
              <select
                value={settings.calendar.defaultMeetingDuration}
                onChange={(e) => setSettings(prev => ({
                  ...prev,
                  calendar: { ...prev.calendar, defaultMeetingDuration: parseInt(e.target.value) }
                }))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
              >
                <option value={15}>15 minutes</option>
                <option value={30}>30 minutes</option>
                <option value={60}>1 hour</option>
                <option value={90}>1.5 hours</option>
                <option value={120}>2 hours</option>
              </select>
            </div>
            
            {Object.entries(settings.calendar).map(([key, value]) => (
              typeof value === 'boolean' && (
              <div key={key} className="flex items-center justify-between">
                <span className="text-white capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </span>
                <button
                  onClick={() => handleToggle('calendar', key)}
                  className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                    value ? 'bg-yellow-400' : 'bg-gray-700'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                    value ? 'right-0.5' : 'left-0.5'
                  }`}></div>
                </button>
              </div>
              )
            ))}
          </div>
        </div>
      </div>

      {/* Account Management */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-yellow-400 rounded-lg">
            <User className="w-5 h-5 text-black" />
          </div>
          <h3 className="text-lg font-semibold text-white">Account Management</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Name</label>
              <input
                type="text"
                value={settings.account.name}
                onChange={(e) => setSettings(prev => ({
                  ...prev,
                  account: { ...prev.account, name: e.target.value }
                }))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Email</label>
              <input
                type="email"
                value={settings.account.email}
                onChange={(e) => setSettings(prev => ({
                  ...prev,
                  account: { ...prev.account, email: e.target.value }
                }))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Plan</label>
              <div className="flex items-center space-x-2">
                <span className="text-white">{settings.account.plan}</span>
                <span className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full">
                  {settings.account.plan === 'Free' ? 'Limited features' : 'All features'}
                </span>
              </div>
            </div>
          </div>
          
          <div className="space-y-3">
            <Button icon={Save} onClick={saveSettings} className="w-full">
              Save Changes
            </Button>
            
            <Button icon={Download} onClick={exportData} variant="outline" className="w-full">
              Export My Data
            </Button>
            
            <Button 
              icon={Trash2} 
              onClick={deleteAccount} 
              variant="outline" 
              className="w-full border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
            >
              Delete Account
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;