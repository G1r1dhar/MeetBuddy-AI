import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Shield, 
  Palette, 
  Link, 
  Bell, 
  Database,
  Key,
  Save,
  AlertTriangle
} from 'lucide-react';
import Button from '../../components/UI/Button';

const AdminSettings: React.FC = () => {
  const [settings, setSettings] = useState({
    general: {
      appName: 'MeetBuddy AI',
      appDescription: 'AI-powered meeting transcription and analysis',
      maintenanceMode: false,
      allowRegistration: true,
      maxUsersPerMeeting: 50
    },
    security: {
      requireTwoFactor: false,
      passwordMinLength: 8,
      sessionTimeout: 30,
      maxLoginAttempts: 5,
      auditLogging: true
    },
    integrations: {
      googleMeet: {
        enabled: true,
        apiKey: '••••••••••••••••',
        webhookUrl: 'https://api.meetbuddy.ai/webhooks/google'
      },
      zoom: {
        enabled: false,
        apiKey: '',
        webhookUrl: ''
      },
      slack: {
        enabled: true,
        botToken: '••••••••••••••••',
        channelId: '#meetings'
      }
    },
    notifications: {
      emailNotifications: true,
      pushNotifications: true,
      systemAlerts: true,
      maintenanceAlerts: true
    }
  });

  const handleToggle = (section: string, key: string, subKey?: string) => {
    setSettings(prev => {
      if (subKey) {
        return {
          ...prev,
          [section]: {
            ...prev[section as keyof typeof prev],
            [key]: {
              ...prev[section as keyof typeof prev][key as keyof (typeof prev)[typeof section]],
              [subKey]: !prev[section as keyof typeof prev][key as keyof (typeof prev)[typeof section]][subKey as keyof (typeof prev)[typeof section][typeof key]]
            }
          }
        };
      } else {
        return {
          ...prev,
          [section]: {
            ...prev[section as keyof typeof prev],
            [key]: !prev[section as keyof typeof prev][key as keyof (typeof prev)[typeof section]]
          }
        };
      }
    });
  };

  const handleInputChange = (section: string, key: string, value: string | number, subKey?: string) => {
    setSettings(prev => {
      if (subKey) {
        return {
          ...prev,
          [section]: {
            ...prev[section as keyof typeof prev],
            [key]: {
              ...prev[section as keyof typeof prev][key as keyof (typeof prev)[typeof section]],
              [subKey]: value
            }
          }
        };
      } else {
        return {
          ...prev,
          [section]: {
            ...prev[section as keyof typeof prev],
            [key]: value
          }
        };
      }
    });
  };

  const saveSettings = () => {
    console.log('Saving settings:', settings);
    // Implementation for saving settings
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Admin Settings</h1>
          <p className="text-gray-400">Configure system settings and integrations</p>
        </div>
        <Button icon={Save} onClick={saveSettings}>
          Save Changes
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* General Settings */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <SettingsIcon className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">General Settings</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Application Name</label>
              <input
                type="text"
                value={settings.general.appName}
                onChange={(e) => handleInputChange('general', 'appName', e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Description</label>
              <textarea
                value={settings.general.appDescription}
                onChange={(e) => handleInputChange('general', 'appDescription', e.target.value)}
                rows={3}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-white">Maintenance Mode</span>
              <button
                onClick={() => handleToggle('general', 'maintenanceMode')}
                className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                  settings.general.maintenanceMode ? 'bg-yellow-400' : 'bg-gray-700'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                  settings.general.maintenanceMode ? 'right-0.5' : 'left-0.5'
                }`}></div>
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-white">Allow Registration</span>
              <button
                onClick={() => handleToggle('general', 'allowRegistration')}
                className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                  settings.general.allowRegistration ? 'bg-yellow-400' : 'bg-gray-700'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                  settings.general.allowRegistration ? 'right-0.5' : 'left-0.5'
                }`}></div>
              </button>
            </div>
          </div>
        </div>

        {/* Security Settings */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <Shield className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">Security Settings</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-white">Require Two-Factor Auth</span>
              <button
                onClick={() => handleToggle('security', 'requireTwoFactor')}
                className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                  settings.security.requireTwoFactor ? 'bg-yellow-400' : 'bg-gray-700'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                  settings.security.requireTwoFactor ? 'right-0.5' : 'left-0.5'
                }`}></div>
              </button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Password Min Length</label>
              <input
                type="number"
                value={settings.security.passwordMinLength}
                onChange={(e) => handleInputChange('security', 'passwordMinLength', parseInt(e.target.value))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Session Timeout (minutes)</label>
              <input
                type="number"
                value={settings.security.sessionTimeout}
                onChange={(e) => handleInputChange('security', 'sessionTimeout', parseInt(e.target.value))}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-white">Audit Logging</span>
              <button
                onClick={() => handleToggle('security', 'auditLogging')}
                className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                  settings.security.auditLogging ? 'bg-yellow-400' : 'bg-gray-700'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                  settings.security.auditLogging ? 'right-0.5' : 'left-0.5'
                }`}></div>
              </button>
            </div>
          </div>
        </div>

        {/* Integrations */}
        <div className="lg:col-span-2 bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <Link className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">Integrations</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Google Meet */}
            <div className="bg-gray-800 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-white">Google Meet</h4>
                <button
                  onClick={() => handleToggle('integrations', 'googleMeet', 'enabled')}
                  className={`w-10 h-5 rounded-full relative transition-all duration-300 ${
                    settings.integrations.googleMeet.enabled ? 'bg-yellow-400' : 'bg-gray-700'
                  }`}
                >
                  <div className={`w-4 h-4 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                    settings.integrations.googleMeet.enabled ? 'right-0.5' : 'left-0.5'
                  }`}></div>
                </button>
              </div>
              <div className="space-y-2">
                <input
                  type="password"
                  placeholder="API Key"
                  value={settings.integrations.googleMeet.apiKey}
                  onChange={(e) => handleInputChange('integrations', 'googleMeet', e.target.value, 'apiKey')}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20"
                />
                <input
                  type="url"
                  placeholder="Webhook URL"
                  value={settings.integrations.googleMeet.webhookUrl}
                  onChange={(e) => handleInputChange('integrations', 'googleMeet', e.target.value, 'webhookUrl')}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20"
                />
              </div>
            </div>

            {/* Zoom */}
            <div className="bg-gray-800 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-white">Zoom</h4>
                <button
                  onClick={() => handleToggle('integrations', 'zoom', 'enabled')}
                  className={`w-10 h-5 rounded-full relative transition-all duration-300 ${
                    settings.integrations.zoom.enabled ? 'bg-yellow-400' : 'bg-gray-700'
                  }`}
                >
                  <div className={`w-4 h-4 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                    settings.integrations.zoom.enabled ? 'right-0.5' : 'left-0.5'
                  }`}></div>
                </button>
              </div>
              <div className="space-y-2">
                <input
                  type="password"
                  placeholder="API Key"
                  value={settings.integrations.zoom.apiKey}
                  onChange={(e) => handleInputChange('integrations', 'zoom', e.target.value, 'apiKey')}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20"
                />
                <input
                  type="url"
                  placeholder="Webhook URL"
                  value={settings.integrations.zoom.webhookUrl}
                  onChange={(e) => handleInputChange('integrations', 'zoom', e.target.value, 'webhookUrl')}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20"
                />
              </div>
            </div>

            {/* Slack */}
            <div className="bg-gray-800 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-white">Slack</h4>
                <button
                  onClick={() => handleToggle('integrations', 'slack', 'enabled')}
                  className={`w-10 h-5 rounded-full relative transition-all duration-300 ${
                    settings.integrations.slack.enabled ? 'bg-yellow-400' : 'bg-gray-700'
                  }`}
                >
                  <div className={`w-4 h-4 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                    settings.integrations.slack.enabled ? 'right-0.5' : 'left-0.5'
                  }`}></div>
                </button>
              </div>
              <div className="space-y-2">
                <input
                  type="password"
                  placeholder="Bot Token"
                  value={settings.integrations.slack.botToken}
                  onChange={(e) => handleInputChange('integrations', 'slack', e.target.value, 'botToken')}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20"
                />
                <input
                  type="text"
                  placeholder="Channel ID"
                  value={settings.integrations.slack.channelId}
                  onChange={(e) => handleInputChange('integrations', 'slack', e.target.value, 'channelId')}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white text-sm focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400/20"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <Bell className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">Notifications</h3>
          </div>
          
          <div className="space-y-4">
            {Object.entries(settings.notifications).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-white capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </span>
                <button
                  onClick={() => handleToggle('notifications', key)}
                  className={`w-12 h-6 rounded-full relative transition-all duration-300 ${
                    value ? 'bg-yellow-400' : 'bg-gray-700'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                    value ? 'right-0.5' : 'left-0.5'
                  }`}></div>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* System Status */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-yellow-400 rounded-lg">
              <Database className="w-5 h-5 text-black" />
            </div>
            <h3 className="text-lg font-semibold text-white">System Status</h3>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Database</span>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-green-400 text-sm">Healthy</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">API Services</span>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-green-400 text-sm">Online</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Storage</span>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span className="text-yellow-400 text-sm">75% Used</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Backup</span>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-green-400 text-sm">Last: 2h ago</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;