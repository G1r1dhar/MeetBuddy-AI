import React, { useState } from 'react';
import { 
  Download, 
  FileText, 
  BarChart3, 
  Calendar, 
  Users,
  Activity,
  TrendingUp,
  Filter
} from 'lucide-react';
import Button from '../../components/UI/Button';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

const Reports: React.FC = () => {
  const [reportType, setReportType] = useState('usage');
  const [dateRange, setDateRange] = useState('month');

  // Sample data for reports
  const usageData = [
    { date: '2025-01-01', meetings: 12, transcripts: 10, users: 45 },
    { date: '2025-01-02', meetings: 15, transcripts: 13, users: 52 },
    { date: '2025-01-03', meetings: 8, transcripts: 7, users: 38 },
    { date: '2025-01-04', meetings: 18, transcripts: 16, users: 61 },
    { date: '2025-01-05', meetings: 14, transcripts: 12, users: 48 },
    { date: '2025-01-06', meetings: 22, transcripts: 19, users: 73 },
    { date: '2025-01-07', meetings: 16, transcripts: 14, users: 55 },
  ];

  const systemLogs = [
    {
      id: '1',
      timestamp: '2025-01-09 14:32:15',
      level: 'INFO',
      message: 'User john@meetbuddy.ai logged in successfully',
      source: 'AUTH_SERVICE'
    },
    {
      id: '2',
      timestamp: '2025-01-09 14:28:42',
      level: 'ERROR',
      message: 'Failed to generate transcript for meeting ID: meet-456',
      source: 'TRANSCRIPT_SERVICE'
    },
    {
      id: '3',
      timestamp: '2025-01-09 14:25:18',
      level: 'WARN',
      message: 'High memory usage detected on server instance 2',
      source: 'SYSTEM_MONITOR'
    },
    {
      id: '4',
      timestamp: '2025-01-09 14:20:33',
      level: 'INFO',
      message: 'Meeting recording started for session: meet-789',
      source: 'RECORDING_SERVICE'
    },
    {
      id: '5',
      timestamp: '2025-01-09 14:15:07',
      level: 'INFO',
      message: 'API request processed: GET /api/meetings',
      source: 'API_GATEWAY'
    }
  ];

  const reportTemplates = [
    {
      name: 'Usage Report',
      description: 'Detailed usage statistics and metrics',
      type: 'usage',
      formats: ['PDF', 'Excel', 'CSV']
    },
    {
      name: 'User Activity Report',
      description: 'User engagement and activity patterns',
      type: 'activity',
      formats: ['PDF', 'Excel']
    },
    {
      name: 'System Performance Report',
      description: 'System health and performance metrics',
      type: 'performance',
      formats: ['PDF', 'JSON']
    },
    {
      name: 'Financial Report',
      description: 'Revenue and subscription analytics',
      type: 'financial',
      formats: ['PDF', 'Excel']
    }
  ];

  const handleDownloadReport = (reportType: string, format: string) => {
    console.log(`Downloading ${reportType} report in ${format} format`);
    // Implementation for downloading reports
  };

  const handleDownloadLogs = () => {
    const logsData = systemLogs.map(log => 
      `${log.timestamp} [${log.level}] ${log.source}: ${log.message}`
    ).join('\n');
    
    const element = document.createElement('a');
    const file = new Blob([logsData], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `system-logs-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'ERROR': return 'text-red-400 bg-red-900/20';
      case 'WARN': return 'text-yellow-400 bg-yellow-900/20';
      case 'INFO': return 'text-blue-400 bg-blue-900/20';
      default: return 'text-gray-400 bg-gray-900/20';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Reports & Logs</h1>
          <p className="text-gray-400">Generate reports and monitor system logs</p>
        </div>
        <Button icon={Download} onClick={handleDownloadLogs}>
          Download Logs
        </Button>
      </div>

      {/* Report Generation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Generate Reports</h3>
          <div className="space-y-4">
            {reportTemplates.map((template, index) => (
              <div key={index} className="bg-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-white">{template.name}</h4>
                  <FileText className="w-5 h-5 text-gray-400" />
                </div>
                <p className="text-sm text-gray-400 mb-3">{template.description}</p>
                <div className="flex flex-wrap gap-2">
                  {template.formats.map((format) => (
                    <button
                      key={format}
                      onClick={() => handleDownloadReport(template.type, format)}
                      className="px-3 py-1 bg-yellow-400 text-black text-xs font-medium rounded hover:bg-yellow-500 transition-colors"
                    >
                      {format}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Quick Statistics</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-800 rounded-lg p-4 text-center">
              <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">1,247</p>
              <p className="text-sm text-gray-400">Total Users</p>
            </div>
            <div className="bg-gray-800 rounded-lg p-4 text-center">
              <Calendar className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">3,456</p>
              <p className="text-sm text-gray-400">Total Meetings</p>
            </div>
            <div className="bg-gray-800 rounded-lg p-4 text-center">
              <FileText className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">2,891</p>
              <p className="text-sm text-gray-400">Transcripts</p>
            </div>
            <div className="bg-gray-800 rounded-lg p-4 text-center">
              <TrendingUp className="w-8 h-8 text-orange-400 mx-auto mb-2" />
              <p className="text-2xl font-bold text-white">+15%</p>
              <p className="text-sm text-gray-400">Growth</p>
            </div>
          </div>
        </div>
      </div>

      {/* Usage Analytics Chart */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Usage Analytics</h3>
          <div className="flex space-x-2">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-1 text-white text-sm focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
            >
              <option value="week">Last 7 Days</option>
              <option value="month">Last 30 Days</option>
              <option value="quarter">Last 3 Months</option>
            </select>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={usageData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis dataKey="date" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1f2937', 
                border: '1px solid #374151',
                borderRadius: '8px',
                color: '#fff'
              }} 
            />
            <Line 
              type="monotone" 
              dataKey="meetings" 
              stroke="#3b82f6" 
              strokeWidth={2}
              name="Meetings"
            />
            <Line 
              type="monotone" 
              dataKey="transcripts" 
              stroke="#10b981" 
              strokeWidth={2}
              name="Transcripts"
            />
            <Line 
              type="monotone" 
              dataKey="users" 
              stroke="#f59e0b" 
              strokeWidth={2}
              name="Active Users"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* System Logs */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">System Logs</h3>
          <div className="flex space-x-2">
            <select className="bg-gray-800 border border-gray-700 rounded-lg px-3 py-1 text-white text-sm focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300">
              <option value="all">All Levels</option>
              <option value="error">Errors Only</option>
              <option value="warn">Warnings</option>
              <option value="info">Info</option>
            </select>
            <Button size="sm" variant="outline" onClick={handleDownloadLogs}>
              Export Logs
            </Button>
          </div>
        </div>
        
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {systemLogs.map((log) => (
            <div key={log.id} className="bg-gray-800 rounded-lg p-3 font-mono text-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-gray-400">{log.timestamp}</span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${getLevelColor(log.level)}`}>
                    {log.level}
                  </span>
                  <span className="text-gray-500">{log.source}</span>
                </div>
              </div>
              <p className="text-gray-300 mt-1">{log.message}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Reports;