import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Filter, 
  Download, 
  Edit, 
  Trash2, 
  Eye,
  Calendar,
  User,
  Tag
} from 'lucide-react';
import Button from '../../components/UI/Button';

interface Content {
  id: string;
  title: string;
  type: 'transcript' | 'summary' | 'notes';
  author: string;
  date: string;
  status: 'approved' | 'pending' | 'rejected';
  tags: string[];
  size: string;
  meetingId: string;
}

const ContentManagement: React.FC = () => {
  const [content, setContent] = useState<Content[]>([
    {
      id: '1',
      title: 'Team Standup Meeting Transcript',
      type: 'transcript',
      author: 'John Doe',
      date: '2025-01-09',
      status: 'approved',
      tags: ['standup', 'team', 'daily'],
      size: '2.3 MB',
      meetingId: 'meet-001'
    },
    {
      id: '2',
      title: 'Client Presentation Summary',
      type: 'summary',
      author: 'Alice Smith',
      date: '2025-01-08',
      status: 'pending',
      tags: ['client', 'presentation', 'quarterly'],
      size: '156 KB',
      meetingId: 'meet-002'
    },
    {
      id: '3',
      title: 'Project Planning Notes',
      type: 'notes',
      author: 'Bob Johnson',
      date: '2025-01-07',
      status: 'approved',
      tags: ['planning', 'project', 'roadmap'],
      size: '89 KB',
      meetingId: 'meet-003'
    },
    {
      id: '4',
      title: 'Budget Review Transcript',
      type: 'transcript',
      author: 'Sarah Wilson',
      date: '2025-01-06',
      status: 'rejected',
      tags: ['budget', 'finance', 'review'],
      size: '1.8 MB',
      meetingId: 'meet-004'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredContent = content.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'transcript': return FileText;
      case 'summary': return Eye;
      case 'notes': return Edit;
      default: return FileText;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'transcript': return 'bg-blue-600';
      case 'summary': return 'bg-green-600';
      case 'notes': return 'bg-purple-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-600';
      case 'pending': return 'bg-yellow-600';
      case 'rejected': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const handleStatusChange = (contentId: string, newStatus: 'approved' | 'pending' | 'rejected') => {
    setContent(content.map(item => 
      item.id === contentId ? { ...item, status: newStatus } : item
    ));
  };

  const handleDelete = (contentId: string) => {
    if (confirm('Are you sure you want to delete this content?')) {
      setContent(content.filter(item => item.id !== contentId));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Content Management</h1>
          <p className="text-gray-400">Manage transcripts, summaries, and meeting notes</p>
        </div>
        <Button icon={Download}>
          Export All
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <FileText className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-2xl font-bold text-white">{content.length}</p>
              <p className="text-sm text-gray-400">Total Content</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Eye className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {content.filter(c => c.status === 'approved').length}
              </p>
              <p className="text-sm text-gray-400">Approved</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Calendar className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {content.filter(c => c.status === 'pending').length}
              </p>
              <p className="text-sm text-gray-400">Pending</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Trash2 className="w-8 h-8 text-red-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {content.filter(c => c.status === 'rejected').length}
              </p>
              <p className="text-sm text-gray-400">Rejected</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search content..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
            />
          </div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
          >
            <option value="all">All Types</option>
            <option value="transcript">Transcripts</option>
            <option value="summary">Summaries</option>
            <option value="notes">Notes</option>
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
          >
            <option value="all">All Status</option>
            <option value="approved">Approved</option>
            <option value="pending">Pending</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Content Table */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-800 border-b border-gray-700">
              <tr>
                <th className="text-left p-4 font-semibold text-white">Content</th>
                <th className="text-left p-4 font-semibold text-white">Type</th>
                <th className="text-left p-4 font-semibold text-white">Author</th>
                <th className="text-left p-4 font-semibold text-white">Date</th>
                <th className="text-left p-4 font-semibold text-white">Status</th>
                <th className="text-left p-4 font-semibold text-white">Size</th>
                <th className="text-left p-4 font-semibold text-white">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredContent.map((item) => {
                const TypeIcon = getTypeIcon(item.type);
                return (
                  <tr key={item.id} className="border-b border-gray-800 hover:bg-gray-800/50 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded ${getTypeColor(item.type)}`}>
                          <TypeIcon className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-white">{item.title}</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {item.tags.map((tag, index) => (
                              <span key={index} className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-white capitalize">{item.type}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-300">{item.author}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-gray-300">{item.date}</span>
                    </td>
                    <td className="p-4">
                      <select
                        value={item.status}
                        onChange={(e) => handleStatusChange(item.id, e.target.value as any)}
                        className={`px-2 py-1 rounded text-xs font-medium text-white border-0 ${getStatusColor(item.status)}`}
                      >
                        <option value="approved">Approved</option>
                        <option value="pending">Pending</option>
                        <option value="rejected">Rejected</option>
                      </select>
                    </td>
                    <td className="p-4">
                      <span className="text-gray-300">{item.size}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors">
                          <Download className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(item.id)}
                          className="p-2 text-gray-400 hover:text-red-400 hover:bg-gray-700 rounded transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ContentManagement;