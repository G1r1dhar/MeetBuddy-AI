import React from 'react';
import { 
  Users, 
  Calendar, 
  FileText, 
  TrendingUp, 
  Activity,
  UserPlus,
  Clock,
  Database,
  Settings
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';

const AdminDashboard: React.FC = () => {
  // Sample data for charts
  const monthlyData = [
    { month: 'Jan', meetings: 45, users: 12, transcripts: 38 },
    { month: 'Feb', meetings: 52, users: 18, transcripts: 45 },
    { month: 'Mar', meetings: 48, users: 15, transcripts: 42 },
    { month: 'Apr', meetings: 61, users: 22, transcripts: 55 },
    { month: 'May', meetings: 55, users: 19, transcripts: 48 },
    { month: 'Jun', meetings: 67, users: 25, transcripts: 58 },
  ];

  const userActivityData = [
    { day: 'Mon', active: 85 },
    { day: 'Tue', active: 92 },
    { day: 'Wed', active: 78 },
    { day: 'Thu', active: 95 },
    { day: 'Fri', active: 88 },
    { day: 'Sat', active: 45 },
    { day: 'Sun', active: 32 },
  ];

  const userTypeData = [
    { name: 'Active Users', value: 68, color: '#10b981' },
    { name: 'New Users', value: 25, color: '#f59e0b' },
    { name: 'Inactive Users', value: 7, color: '#ef4444' },
  ];

  const StatCard = ({ title, value, subtitle, icon: Icon, color, trend }: any) => (
    <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-400 mb-1">{title}</p>
          <p className="text-3xl font-bold text-white mb-1">{value}</p>
          <p className="text-sm text-gray-400">{subtitle}</p>
          {trend && (
            <p className={`text-sm mt-2 ${trend > 0 ? 'text-green-400' : 'text-red-400'}`}>
              {trend > 0 ? '↗' : '↘'} {Math.abs(trend)}% from last month
            </p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
        <p className="text-gray-400">Overview of system performance and user activity</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Users"
          value="1,247"
          subtitle="registered users"
          icon={Users}
          color="bg-blue-600"
          trend={12}
        />
        <StatCard
          title="Active Users"
          value="892"
          subtitle="this month"
          icon={Activity}
          color="bg-green-600"
          trend={8}
        />
        <StatCard
          title="Total Meetings"
          value="3,456"
          subtitle="all time"
          icon={Calendar}
          color="bg-purple-600"
          trend={15}
        />
        <StatCard
          title="Transcripts Generated"
          value="2,891"
          subtitle="this month"
          icon={FileText}
          color="bg-orange-600"
          trend={-3}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Activity Chart */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Monthly Activity</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="month" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1f2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#fff'
                }} 
              />
              <Bar dataKey="meetings" fill="#3b82f6" name="Meetings" />
              <Bar dataKey="transcripts" fill="#f59e0b" name="Transcripts" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* User Activity Trend */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Daily Active Users</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={userActivityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="day" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1f2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#fff'
                }} 
              />
              <Line 
                type="monotone" 
                dataKey="active" 
                stroke="#10b981" 
                strokeWidth={3}
                dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User Distribution */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">User Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={userTypeData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {userTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1f2937', 
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#fff'
                }} 
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {userTypeData.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-sm text-gray-300">{item.name}</span>
                </div>
                <span className="text-sm font-medium text-white">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="lg:col-span-2 bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {[
              { user: 'John Doe', action: 'Created new meeting', time: '2 minutes ago', type: 'meeting' },
              { user: 'Alice Smith', action: 'Generated transcript', time: '5 minutes ago', type: 'transcript' },
              { user: 'Bob Johnson', action: 'Joined the platform', time: '10 minutes ago', type: 'user' },
              { user: 'Sarah Wilson', action: 'Exported meeting summary', time: '15 minutes ago', type: 'export' },
              { user: 'Mike Brown', action: 'Updated profile settings', time: '20 minutes ago', type: 'settings' },
            ].map((activity, index) => (
              <div key={index} className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  activity.type === 'meeting' ? 'bg-blue-600' :
                  activity.type === 'transcript' ? 'bg-green-600' :
                  activity.type === 'user' ? 'bg-purple-600' :
                  activity.type === 'export' ? 'bg-orange-600' : 'bg-gray-600'
                }`}>
                  {activity.type === 'meeting' && <Calendar className="w-4 h-4 text-white" />}
                  {activity.type === 'transcript' && <FileText className="w-4 h-4 text-white" />}
                  {activity.type === 'user' && <UserPlus className="w-4 h-4 text-white" />}
                  {activity.type === 'export' && <Database className="w-4 h-4 text-white" />}
                  {activity.type === 'settings' && <Settings className="w-4 h-4 text-white" />}
                </div>
                <div className="flex-1">
                  <p className="text-white font-medium">{activity.user}</p>
                  <p className="text-sm text-gray-400">{activity.action}</p>
                </div>
                <div className="text-xs text-gray-500">{activity.time}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;