import React, { useState } from 'react';
import { 
  Calendar, 
  Search, 
  Filter, 
  Video, 
  Users, 
  Clock, 
  Download,
  Play,
  Pause,
  Square,
  Eye
} from 'lucide-react';
import Button from '../../components/UI/Button';

interface Meeting {
  id: string;
  title: string;
  organizer: string;
  participants: string[];
  date: string;
  time: string;
  duration: string;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  meetLink?: string;
  hasTranscript: boolean;
  hasSummary: boolean;
  recordingSize?: string;
}

const MeetingManagement: React.FC = () => {
  const [meetings, setMeetings] = useState<Meeting[]>([
    {
      id: '1',
      title: 'Team Standup Meeting',
      organizer: 'John Doe',
      participants: ['Alice Smith', 'Bob Johnson', 'Sarah Wilson'],
      date: '2025-01-10',
      time: '09:00',
      duration: '30 min',
      status: 'scheduled',
      meetLink: 'https://meet.google.com/abc-defg-hij',
      hasTranscript: false,
      hasSummary: false
    },
    {
      id: '2',
      title: 'Client Presentation',
      organizer: 'Alice Smith',
      participants: ['John Doe', 'Client Team', 'Manager'],
      date: '2025-01-09',
      time: '14:00',
      duration: '1h 30min',
      status: 'completed',
      meetLink: 'https://meet.google.com/xyz-uvw-rst',
      hasTranscript: true,
      hasSummary: true,
      recordingSize: '2.3 GB'
    },
    {
      id: '3',
      title: 'Project Planning Session',
      organizer: 'Bob Johnson',
      participants: ['Team A', 'Team B', 'Stakeholders'],
      date: '2025-01-09',
      time: '10:30',
      duration: '2h',
      status: 'in-progress',
      meetLink: 'https://meet.google.com/planning-session',
      hasTranscript: true,
      hasSummary: false
    },
    {
      id: '4',
      title: 'Budget Review',
      organizer: 'Sarah Wilson',
      participants: ['Finance Team', 'Department Heads'],
      date: '2025-01-08',
      time: '15:00',
      duration: '1h',
      status: 'cancelled',
      hasTranscript: false,
      hasSummary: false
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all');

  const filteredMeetings = meetings.filter(meeting => {
    const matchesSearch = meeting.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         meeting.organizer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || meeting.status === statusFilter;
    
    let matchesDate = true;
    if (dateFilter === 'today') {
      matchesDate = meeting.date === new Date().toISOString().split('T')[0];
    } else if (dateFilter === 'week') {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      matchesDate = new Date(meeting.date) >= weekAgo;
    }
    
    return matchesSearch && matchesStatus && matchesDate;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-600';
      case 'in-progress': return 'bg-green-600';
      case 'completed': return 'bg-gray-600';
      case 'cancelled': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'scheduled': return Calendar;
      case 'in-progress': return Play;
      case 'completed': return Square;
      case 'cancelled': return Pause;
      default: return Calendar;
    }
  };

  const handleJoinMeeting = (meetLink: string) => {
    window.open(meetLink, '_blank');
  };

  const handleExportMeeting = (meetingId: string) => {
    console.log('Exporting meeting:', meetingId);
    // Implementation for exporting meeting data
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Meeting Management</h1>
          <p className="text-gray-400">Monitor and manage all meetings and sessions</p>
        </div>
        <Button icon={Calendar}>
          Schedule Meeting
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Calendar className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-2xl font-bold text-white">{meetings.length}</p>
              <p className="text-sm text-gray-400">Total Meetings</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Play className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {meetings.filter(m => m.status === 'in-progress').length}
              </p>
              <p className="text-sm text-gray-400">In Progress</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Square className="w-8 h-8 text-gray-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {meetings.filter(m => m.status === 'completed').length}
              </p>
              <p className="text-sm text-gray-400">Completed</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Download className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {meetings.filter(m => m.hasTranscript).length}
              </p>
              <p className="text-sm text-gray-400">With Transcripts</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search meetings..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
          >
            <option value="all">All Status</option>
            <option value="scheduled">Scheduled</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
          >
            <option value="all">All Time</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
          </select>
        </div>
      </div>

      {/* Meetings Table */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-800 border-b border-gray-700">
              <tr>
                <th className="text-left p-4 font-semibold text-white">Meeting</th>
                <th className="text-left p-4 font-semibold text-white">Organizer</th>
                <th className="text-left p-4 font-semibold text-white">Date & Time</th>
                <th className="text-left p-4 font-semibold text-white">Status</th>
                <th className="text-left p-4 font-semibold text-white">Participants</th>
                <th className="text-left p-4 font-semibold text-white">Content</th>
                <th className="text-left p-4 font-semibold text-white">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredMeetings.map((meeting) => {
                const StatusIcon = getStatusIcon(meeting.status);
                return (
                  <tr key={meeting.id} className="border-b border-gray-800 hover:bg-gray-800/50 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded ${getStatusColor(meeting.status)}`}>
                          <StatusIcon className="w-4 h-4 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-white">{meeting.title}</p>
                          <p className="text-sm text-gray-400">{meeting.duration}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-gray-300">{meeting.organizer}</span>
                    </td>
                    <td className="p-4">
                      <div className="text-gray-300">
                        <p>{meeting.date}</p>
                        <p className="text-sm text-gray-400">{meeting.time}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(meeting.status)}`}>
                        {meeting.status.replace('-', ' ')}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4 text-gray-400" />
                        <span className="text-gray-300">{meeting.participants.length}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        {meeting.hasTranscript && (
                          <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded">
                            Transcript
                          </span>
                        )}
                        {meeting.hasSummary && (
                          <span className="text-xs bg-green-600 text-white px-2 py-1 rounded">
                            Summary
                          </span>
                        )}
                        {meeting.recordingSize && (
                          <span className="text-xs bg-purple-600 text-white px-2 py-1 rounded">
                            {meeting.recordingSize}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        {meeting.meetLink && meeting.status === 'scheduled' && (
                          <button
                            onClick={() => handleJoinMeeting(meeting.meetLink!)}
                            className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors"
                          >
                            <Video className="w-4 h-4" />
                          </button>
                        )}
                        {meeting.status === 'completed' && (
                          <>
                            <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors">
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleExportMeeting(meeting.id)}
                              className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded transition-colors"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Real-time Monitoring */}
      {meetings.some(m => m.status === 'in-progress') && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Live Sessions</h3>
          <div className="space-y-4">
            {meetings.filter(m => m.status === 'in-progress').map((meeting) => (
              <div key={meeting.id} className="bg-gray-800 rounded-lg p-4 border-l-4 border-green-500">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-white">{meeting.title}</h4>
                    <p className="text-sm text-gray-400">
                      Started at {meeting.time} • {meeting.participants.length} participants
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm text-green-400">Live</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default MeetingManagement;