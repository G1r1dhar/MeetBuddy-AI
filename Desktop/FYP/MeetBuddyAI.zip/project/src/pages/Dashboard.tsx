import React from 'react';
import { TrendingUp, Calendar, Database, Sparkles, Plus, CalendarDays, Video } from 'lucide-react';
import StatCard from '../components/UI/StatCard';
import Button from '../components/UI/Button';
import { useNotifications } from '../contexts/NotificationContext';
import { useState } from 'react';
import ScheduleMeetingModal from '../components/Calendar/ScheduleMeetingModal';

const Dashboard: React.FC = () => {
  const { addNotification } = useNotifications();
  const [showScheduleModal, setShowScheduleModal] = useState(false);

  const handleScheduleMeeting = () => {
    setShowScheduleModal(true);
  };

  const handleMeetingScheduled = (meetingData: any) => {
    setShowScheduleModal(false);
    addNotification({
      title: 'Meeting Scheduled',
      message: `"${meetingData.title}" has been scheduled successfully.`,
      type: 'success'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Welcome back, John Doe</h1>
          <p className="text-gray-400">Capture and analyze your Google Meet sessions with AI-powered insights</p>
        </div>
        <Button 
          icon={Plus} 
          size="lg"
          onClick={handleScheduleMeeting}
          className="shadow-lg shadow-yellow-400/50"
        >
          Schedule Google Meet
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="This Month"
          value="0"
          subtitle="meetings recorded"
          icon={TrendingUp}
          gradient="bg-gradient-to-r from-blue-600 to-blue-700"
        />
        <StatCard
          title="This Week"
          value="0"
          subtitle="meetings recorded"
          icon={Calendar}
          gradient="bg-gradient-to-r from-green-600 to-green-700"
        />
        <StatCard
          title="Storage Used"
          value="0MB"
          subtitle="of recordings"
          icon={Database}
          gradient="bg-gradient-to-r from-purple-600 to-purple-700"
        />
        <StatCard
          title="AI Summaries"
          value="0"
          subtitle="generated"
          icon={Sparkles}
          gradient="bg-gradient-to-r from-orange-600 to-red-600"
        />
      </div>

      {/* Welcome Section */}
      <div className="bg-gray-900 rounded-xl p-8 text-center border border-gray-800">
        <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-yellow-400/50">
          <CalendarDays className="w-8 h-8 text-black" />
        </div>
        
        <h2 className="text-2xl font-bold text-white mb-4">Welcome to MeetBuddy AI</h2>
        <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
          Start by scheduling your first Google Meet session. We'll capture real-time transcripts 
          and generate AI-powered summaries and insights.
        </p>
        
        <Button 
          icon={Plus}
          size="lg"
          onClick={handleScheduleMeeting}
          className="shadow-lg shadow-yellow-400/50"
        >
          Schedule Your First Meeting
        </Button>
      </div>

      {/* Recent Activity */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
        <div className="p-6 border-b border-gray-800">
          <h3 className="text-xl font-bold text-white">Recent Activity</h3>
        </div>
        <div className="p-6 text-center">
          <CalendarDays className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">No recent meetings found</p>
          <p className="text-sm text-gray-500 mt-2">Your meeting history will appear here</p>
        </div>
      </div>

      {/* Schedule Meeting Modal */}
      {showScheduleModal && (
        <ScheduleMeetingModal
          isOpen={showScheduleModal}
          onClose={() => setShowScheduleModal(false)}
          onSchedule={handleMeetingScheduled}
        />
      )}
    </div>
  );
};

export default Dashboard;