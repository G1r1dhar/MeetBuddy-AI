import React, { useState } from 'react';
import { Video, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import Button from '../components/UI/Button';

interface LoginProps {
  onLogin: (role: 'admin' | 'user') => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login process
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const role = email.includes('admin') ? 'admin' : 'user';
    localStorage.setItem('authToken', 'demo-token');
    localStorage.setItem('userRole', role);
    onLogin(role);
    setIsLoading(false);
  };

  const fillDemoCredentials = () => {
    setEmail('user@meetbuddy.ai');
    setPassword('password123');
  };

  const fillAdminCredentials = () => {
    setEmail('admin@meetbuddy.ai');
    setPassword('admin123');
  };
  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Video className="w-8 h-8 text-black" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Welcome to MeetBuddy AI</h1>
          <p className="text-gray-400">Sign in to your account to continue</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg px-10 py-3 text-white placeholder-gray-400 focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-2">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg px-10 py-3 text-white placeholder-gray-400 focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
                placeholder="Enter your password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            size="lg"
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? 'Signing In...' : 'Sign In'}
          </Button>
        </form>

        <div className="mt-6 p-4 bg-gray-900 rounded-lg border border-gray-800">
          <p className="text-sm text-gray-400 mb-3">Demo credentials:</p>
          <div className="space-y-1 text-xs text-gray-500">
            <p>User: user@meetbuddy.ai / password123</p>
            <p>Admin: admin@meetbuddy.ai / admin123</p>
          </div>
          <div className="flex space-x-2 mt-3">
            <button
              type="button"
              onClick={fillDemoCredentials}
              className="text-sm text-yellow-400 hover:text-yellow-300 transition-colors"
            >
              Fill User
            </button>
            <button
              type="button"
              onClick={fillAdminCredentials}
              className="text-sm text-yellow-400 hover:text-yellow-300 transition-colors"
            >
              Fill Admin
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;