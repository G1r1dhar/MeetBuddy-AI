import React, { useState } from 'react';
import { Calendar, Clock, Users, FileText, Download, Play, Pause } from 'lucide-react';
import Button from '../components/UI/Button';
import ScheduleMeetingModal from '../components/Calendar/ScheduleMeetingModal';
import { useNotifications } from '../contexts/NotificationContext';

interface Meeting {
  id: string;
  title: string;
  date: string;
  time: string;
  duration: string;
  participants: number;
  status: 'scheduled' | 'completed' | 'in-progress';
  transcript?: string;
  summary?: string;
}

const Meetings: React.FC = () => {
  const [meetings] = useState<Meeting[]>([
    {
      id: '1',
      title: 'Team Standup Meeting',
      date: '2025-01-09',
      time: '09:00 AM',
      duration: '30 min',
      participants: 5,
      status: 'scheduled'
    },
    {
      id: '2',
      title: 'Client Presentation',
      date: '2025-01-08',
      time: '02:00 PM',
      duration: '1h 15min',
      participants: 8,
      status: 'completed',
      transcript: 'Meeting transcript available...',
      summary: 'Meeting summary available...'
    }
  ]);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const { addNotification } = useNotifications();

  const handleScheduleMeeting = () => {
    setShowScheduleModal(true);
  };

  const handleMeetingScheduled = (meetingData: any) => {
    setShowScheduleModal(false);
    addNotification({
      title: 'Meeting Scheduled',
      message: `"${meetingData.title}" has been scheduled successfully.`,
      type: 'success'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled': return 'bg-blue-500';
      case 'in-progress': return 'bg-green-500';
      case 'completed': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'scheduled': return 'Scheduled';
      case 'in-progress': return 'In Progress';
      case 'completed': return 'Completed';
      default: return 'Unknown';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Meetings</h1>
          <p className="text-gray-400">Manage your meetings, transcripts, and AI-generated summaries</p>
        </div>
        <Button 
          icon={Calendar} 
          size="lg" 
          className="shadow-lg shadow-yellow-400/50"
          onClick={handleScheduleMeeting}
        >
          Schedule Meeting
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <select className="bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300">
          <option>All Meetings</option>
          <option>Scheduled</option>
          <option>In Progress</option>
          <option>Completed</option>
        </select>
        <select className="bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300">
          <option>This Week</option>
          <option>This Month</option>
          <option>All Time</option>
        </select>
      </div>

      {/* Meetings List */}
      <div className="space-y-4">
        {meetings.map((meeting) => (
          <div key={meeting.id} className="bg-gray-900 rounded-xl border border-gray-800 p-6 hover:border-gray-700 transition-all duration-300">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between space-y-4 lg:space-y-0">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-xl font-semibold text-white">{meeting.title}</h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(meeting.status)}`}>
                    {getStatusText(meeting.status)}
                  </span>
                </div>
                
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{meeting.date}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{meeting.time}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>{meeting.participants} participants</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{meeting.duration}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {meeting.status === 'in-progress' && (
                  <Button variant="secondary" size="sm" icon={Pause}>
                    Stop Recording
                  </Button>
                )}
                {meeting.status === 'scheduled' && (
                  <Button variant="secondary" size="sm" icon={Play}>
                    Start Recording
                  </Button>
                )}
                {meeting.transcript && (
                  <Button variant="outline" size="sm" icon={FileText}>
                    View Transcript
                  </Button>
                )}
                {meeting.summary && (
                  <Button variant="outline" size="sm" icon={FileText}>
                    View Summary
                  </Button>
                )}
                {meeting.status === 'completed' && (
                  <Button variant="outline" size="sm" icon={Download}>
                    Export
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {meetings.length === 0 && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-12 text-center">
          <Calendar className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No meetings found</h3>
          <p className="text-gray-400 mb-6">Schedule your first meeting to get started</p>
          <Button 
            icon={Calendar} 
            className="shadow-lg shadow-yellow-400/50"
            onClick={handleScheduleMeeting}
          >
            Schedule Meeting
          </Button>
        </div>
      )}

      {/* Schedule Meeting Modal */}
      {showScheduleModal && (
        <ScheduleMeetingModal
          isOpen={showScheduleModal}
          onClose={() => setShowScheduleModal(false)}
          onSchedule={handleMeetingScheduled}
        />
      )}
    </div>
  );
};

export default Meetings;