import React, { useState, useEffect } from 'react';
import { Calendar as BigCalendar, momentLocalizer, Views } from 'react-big-calendar';
import moment from 'moment';
import { Plus, Calendar as CalendarIcon, Clock, Users, Video, Edit, Trash2, Bell, Repeat } from 'lucide-react';
import Button from '../components/UI/Button';
import { useNotifications } from '../contexts/NotificationContext';
import ScheduleMeetingModal from '../components/Calendar/ScheduleMeetingModal';
import MeetingDetailsModal from '../components/Calendar/MeetingDetailsModal';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const localizer = momentLocalizer(moment);

interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  resource?: {
    type: 'meeting' | 'reminder';
    meetLink?: string;
    participants?: string[];
    description?: string;
    meetingType?: string;
    recurring?: boolean;
    reminderTime?: string;
    actionItems?: string[];
    summary?: string;
    notes?: string;
  };
}

const Calendar: React.FC = () => {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  const [date, setDate] = useState(new Date());
  const [showEventModal, setShowEventModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const { addNotification } = useNotifications();

  useEffect(() => {
    // Load sample events
    const sampleEvents: CalendarEvent[] = [
      {
        id: '1',
        title: 'Team Standup',
        start: new Date(2025, 0, 10, 9, 0),
        end: new Date(2025, 0, 10, 9, 30),
        resource: {
          type: 'meeting',
          meetLink: 'https://meet.google.com/abc-defg-hij',
          participants: ['John Doe', 'Alice Smith', 'Bob Johnson'],
          description: 'Daily team standup meeting',
          meetingType: 'google-meet',
          recurring: true,
          reminderTime: '15',
          actionItems: ['Review sprint progress', 'Discuss blockers'],
          summary: 'Team discussed current sprint progress and identified key blockers.',
          notes: 'Next sprint planning scheduled for Friday.'
        }
      },
      {
        id: '2',
        title: 'Client Presentation',
        start: new Date(2025, 0, 12, 14, 0),
        end: new Date(2025, 0, 12, 15, 30),
        resource: {
          type: 'meeting',
          meetLink: 'https://meet.google.com/xyz-uvw-rst',
          participants: ['John Doe', 'Client Team'],
          description: 'Quarterly review presentation',
          meetingType: 'google-meet',
          recurring: false,
          reminderTime: '30',
          actionItems: ['Prepare Q2 roadmap', 'Schedule follow-up meeting'],
          summary: 'Presented Q1 results and discussed Q2 objectives with client.',
          notes: 'Client approved proposed timeline and budget adjustments.'
        }
      },
      {
        id: '3',
        title: 'Meeting Reminder',
        start: new Date(2025, 0, 15, 10, 0),
        end: new Date(2025, 0, 15, 10, 0),
        resource: {
          type: 'reminder',
          description: 'Reminder for upcoming project deadline',
          actionItems: ['Complete final review', 'Submit deliverables']
        }
      }
    ];
    setEvents(sampleEvents);
  }, []);

  const handleSelectEvent = (event: CalendarEvent) => {
    setSelectedEvent(event);
    setShowEventModal(true);
  };

  const handleSelectSlot = ({ start, end }: { start: Date; end: Date }) => {
    setShowScheduleModal(true);
  };

  const handleScheduleMeeting = () => {
    setShowScheduleModal(true);
  };

  const handleMeetingScheduled = (meetingData: any) => {
    const newEvent: CalendarEvent = {
      id: meetingData.id,
      title: meetingData.title,
      start: new Date(`${meetingData.date}T${meetingData.time}`),
      end: new Date(new Date(`${meetingData.date}T${meetingData.time}`).getTime() + parseInt(meetingData.duration) * 60000),
      resource: {
        type: 'meeting',
        meetLink: meetingData.meetLink,
        participants: meetingData.participants,
        description: meetingData.description,
        meetingType: meetingData.meetingType,
        recurring: meetingData.recurring,
        reminderTime: meetingData.reminderTime,
        actionItems: []
      }
    };
    
    setEvents(prev => [...prev, newEvent]);
    setShowScheduleModal(false);
    
    addNotification({
      title: 'Meeting Scheduled',
      message: `"${meetingData.title}" has been scheduled successfully.`,
      type: 'success'
    });
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setEditingEvent(event);
    setShowScheduleModal(true);
  };

  const handleDeleteEvent = (eventId: string) => {
    if (confirm('Are you sure you want to delete this meeting?')) {
      setEvents(prev => prev.filter(event => event.id !== eventId));
      setShowEventModal(false);
      addNotification({
        title: 'Meeting Deleted',
        message: 'The meeting has been removed from your calendar.',
        type: 'info'
      });
    }
  };

  const joinMeeting = (meetLink: string) => {
    window.open(meetLink, '_blank');
    addNotification({
      title: 'Joining Meeting',
      message: 'Opening Google Meet in a new tab.',
      type: 'info'
    });
  };

  const eventStyleGetter = (event: CalendarEvent) => {
    const isReminder = event.resource?.type === 'reminder';
    return {
      style: {
        backgroundColor: isReminder ? '#f59e0b' : '#3b82f6',
        borderRadius: '6px',
        opacity: 0.8,
        color: 'white',
        border: '0px',
        display: 'block'
      }
    };
  };

  const CustomToolbar = ({ label, onNavigate, onView }: any) => (
    <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 space-y-4 lg:space-y-0">
      <div className="flex items-center space-x-4">
        <h2 className="text-2xl font-bold text-white">{label}</h2>
        <div className="flex space-x-2">
          <button
            onClick={() => onNavigate('PREV')}
            className="px-3 py-1 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors"
          >
            ←
          </button>
          <button
            onClick={() => onNavigate('TODAY')}
            className="px-3 py-1 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors"
          >
            Today
          </button>
          <button
            onClick={() => onNavigate('NEXT')}
            className="px-3 py-1 bg-gray-800 text-white rounded hover:bg-gray-700 transition-colors"
          >
            →
          </button>
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <div className="flex bg-gray-800 rounded-lg overflow-hidden">
          {['month', 'week', 'day'].map((viewName) => (
            <button
              key={viewName}
              onClick={() => onView(viewName)}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                view === viewName
                  ? 'bg-yellow-400 text-black'
                  : 'text-white hover:bg-gray-700'
              }`}
            >
              {viewName.charAt(0).toUpperCase() + viewName.slice(1)}
            </button>
          ))}
        </div>
        <Button icon={Plus} size="sm" onClick={handleScheduleMeeting}>
          New Event
        </Button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Calendar</h1>
        <p className="text-gray-400">Manage your meetings and schedule with Google Calendar integration</p>
      </div>

      {/* Calendar Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <CalendarIcon className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-2xl font-bold text-white">{events.length}</p>
              <p className="text-sm text-gray-400">Total Events</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Video className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {events.filter(e => e.resource?.type === 'meeting').length}
              </p>
              <p className="text-sm text-gray-400">Meetings</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Clock className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {events.filter(e => e.start > new Date()).length}
              </p>
              <p className="text-sm text-gray-400">Upcoming</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-2xl font-bold text-white">
                {events.reduce((acc, e) => acc + (e.resource?.participants?.length || 0), 0)}
              </p>
              <p className="text-sm text-gray-400">Participants</p>
            </div>
          </div>
        </div>
      </div>

      {/* Calendar Component */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-6">
        <style jsx global>{`
          .rbc-calendar {
            background: transparent;
            color: white;
          }
          .rbc-header {
            background: #374151;
            color: white;
            border-bottom: 1px solid #4b5563;
            padding: 12px 8px;
            font-weight: 600;
          }
          .rbc-month-view, .rbc-time-view {
            background: transparent;
            border: 1px solid #4b5563;
          }
          .rbc-date-cell {
            color: #d1d5db;
            padding: 8px;
          }
          .rbc-date-cell.rbc-off-range {
            color: #6b7280;
          }
          .rbc-today {
            background-color: rgba(251, 191, 36, 0.1);
          }
          .rbc-event {
            border-radius: 6px;
            padding: 2px 6px;
            font-size: 12px;
          }
          .rbc-time-slot {
            border-top: 1px solid #4b5563;
          }
          .rbc-time-header-content {
            border-left: 1px solid #4b5563;
          }
          .rbc-time-content {
            border-top: 1px solid #4b5563;
          }
          .rbc-timeslot-group {
            border-bottom: 1px solid #4b5563;
          }
          .rbc-day-slot .rbc-time-slot {
            border-top: 1px solid #374151;
          }
        `}</style>
        
        <BigCalendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          style={{ height: 600 }}
          view={view}
          onView={(newView) => setView(newView as 'month' | 'week' | 'day')}
          date={date}
          onNavigate={setDate}
          onSelectEvent={handleSelectEvent}
          onSelectSlot={handleSelectSlot}
          selectable
          eventPropGetter={eventStyleGetter}
          components={{
            toolbar: CustomToolbar,
          }}
          views={[Views.MONTH, Views.WEEK, Views.DAY]}
        />
      </div>

      {/* Event Details Modal */}
      {showEventModal && selectedEvent && (
        <MeetingDetailsModal
          event={selectedEvent}
          isOpen={showEventModal}
          onClose={() => setShowEventModal(false)}
          onEdit={handleEditEvent}
          onDelete={handleDeleteEvent}
          onJoinMeeting={joinMeeting}
        />
      )}

      {/* Schedule Meeting Modal */}
      {showScheduleModal && (
        <ScheduleMeetingModal
          isOpen={showScheduleModal}
          onClose={() => {
            setShowScheduleModal(false);
            setEditingEvent(null);
          }}
          onSchedule={handleMeetingScheduled}
          editingEvent={editingEvent}
        />
      )}
    </div>
  );
};

export default Calendar;